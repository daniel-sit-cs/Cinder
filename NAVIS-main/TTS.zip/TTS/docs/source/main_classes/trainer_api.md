# Trainer API

We made the trainer a separate project on https://github.com/coqui-ai/Trainer
